<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: index.html');
    exit();
}

// Database connection
$hostname = "localhost";
$username = "root";
$password = "Ktanooj@2004";
$database = "slog";

$conn = new mysqli($hostname, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch distinct filter options
$departments = $conn->query("SELECT DISTINCT DEPARTMENT FROM Details")->fetch_all(MYSQLI_ASSOC);
$batches = $conn->query("SELECT DISTINCT BATCH FROM Details")->fetch_all(MYSQLI_ASSOC);

// Get today's date
$today = date('Y-m-d');

// Handle form submission
$start_date = !empty($_POST['start_date']) ? $_POST['start_date'] : '2024-01-01'; // Default start date
$end_date = !empty($_POST['end_date']) ? $_POST['end_date'] : $today; // Default end date
$name_filter = !empty($_POST['name']) ? $_POST['name'] : ''; // Name filter
$department_filter = !empty($_POST['department']) ? $_POST['department'] : ''; // Department filter
$batch_filter = !empty($_POST['batch']) ? $_POST['batch'] : ''; // Batch filter

// Calculate months between start_date and end_date
$start = new DateTime($start_date);
$end = new DateTime($end_date);
$interval = new DateInterval('P1M');

// Corrected DatePeriod usage without modifying the $end date
$period = new DatePeriod($start, $interval, $end->modify('last day of this month'));

// Dynamically build the SUM(CASE...) statements for each month
$month_sums = [];
foreach ($period as $date) {
    $month = $date->format('Y-m');
    $alias = $date->format('M_Y'); // e.g., Jan_2024
    $month_sums[] = "SUM(CASE WHEN DATE_FORMAT(e.IN_Time, '%Y-%m') = '$month' THEN 1 ELSE 0 END) AS $alias";
}

// Join the dynamically generated month sums into a single string
$month_sums_sql = implode(", ", $month_sums);

// Build the SQL query with dynamic month sums and filters
$sql = "
SELECT
    d.NAME AS Student_Name,
    d.REGD AS Register_Number,
    d.DEPARTMENT,
    d.BATCH,
    $month_sums_sql
FROM
    ENTRY_Table e
JOIN
    Details d ON e.NAME = d.NAME
WHERE
    (d.NAME LIKE '%$name_filter%' OR '$name_filter' = '')
    AND (d.DEPARTMENT LIKE '%$department_filter%' OR '$department_filter' = '')
    AND (d.BATCH LIKE '%$batch_filter%' OR '$batch_filter' = '')
GROUP BY
    d.NAME,
    d.REGD,
    d.DEPARTMENT,
    d.BATCH
ORDER BY
    d.NAME";

// Execute the query
$result = $conn->query($sql);

// Handle CSV download
if (isset($_POST['download_csv'])) {
    // Prepare the CSV download
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment;filename=attendance_report.csv');

    $output = fopen('php://output', 'w');
    // Add header
    $headers = array('Name', 'Register Number', 'Department', 'Batch');
    foreach ($period as $date) {
        $headers[] = $date->format('M Y'); // e.g., 'Jan 2024'
    }
    fputcsv($output, $headers);

    // Add rows
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            fputcsv($output, $row);
        }
    }

    fclose($output);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Monthly Attendance Report</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap');
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        body {
            min-height: 100vh;
            width: 100%;
            background: #f7f7f7;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
        h1 {
            margin: 20px 0;
            font-size: 36px;
            color: #333;
        }
        form {
            margin: 20px auto;
            text-align: center;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        label {
            margin-right: 10px;
            font-size: 16px;
        }
        input, select, button {
            padding: 10px;
            margin: 10px 5px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        input:focus, select:focus {
            border-color: #007bff;
        }
        button {
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #0056b3;
        }
        table {
            width: 90%;
            margin: 20px auto;
            border-collapse: collapse;
            background: #fff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        th, td {
            padding: 12px 20px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .logout-container {
            width: 90%;
            text-align: left;
            margin: 20px;
        }
        .logout {
            background-color: #c00000;
            border-radius: 100px;
            color: white;
            padding: 10px 30px;
            text-align: center;
            text-decoration: none;
            font-size: 20px;
            cursor: pointer;
            transition: all 250ms ease-in-out;
            border: none;
        }
        .logout:hover {
            background-color: #ff1c1c;
        }
    </style>
</head>
<body>

    <div class="logout-container">
        <a href="ReportPage.php"><button class="logout"><b><-- BACK</b></button></a>
    </div>

    <h1>Monthly Attendance Report</h1>

    <form method="POST" action="">
    <label for="name">Name:</label>
        <input type="text" id="name" name="name" value="<?= htmlspecialchars($name_filter) ?>">

        <label for="department">Department:</label>
        <select id="department" name="department">
            <option value="">All</option>
            <?php foreach ($departments as $department): ?>
                <option value="<?= htmlspecialchars($department['DEPARTMENT']) ?>" <?= ($department['DEPARTMENT'] == $department_filter) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($department['DEPARTMENT']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="batch">Batch:</label>
        <select id="batch" name="batch">
            <option value="">All</option>
            <?php foreach ($batches as $batch): ?>
                <option value="<?= htmlspecialchars($batch['BATCH']) ?>" <?= ($batch['BATCH'] == $batch_filter) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($batch['BATCH']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="start_date">Start Date:</label>
        <input type="date" id="start_date" name="start_date" value="<?= htmlspecialchars($start_date) ?>">

        <label for="end_date">End Date:</label>
        <input type="date" id="end_date" name="end_date" value="<?= htmlspecialchars($end_date) ?>">

        <button type="submit" name="filter">Filter</button>
        <button type="submit" name="download_csv">Download CSV</button>
    </form>

    <table id="dataTable">
        <tr>
            <th>Name</th>
            <th>Register Number</th>
            <th>Department</th>
            <th>Batch</th>
            <?php foreach ($period as $date): ?>
                <th><?= $date->format('M Y') ?></th>
            <?php endforeach; ?>
        </tr>
        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['Student_Name']) ?></td>
                    <td><?= htmlspecialchars($row['Register_Number']) ?></td>
                    <td><?= htmlspecialchars($row['DEPARTMENT']) ?></td>
                    <td><?= htmlspecialchars($row['BATCH']) ?></td>
                    <?php foreach ($period as $date): ?>
                        <td><?= htmlspecialchars($row[$date->format('M_Y')]) ?></td>
                    <?php endforeach; ?>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="4">No records found</td>
            </tr>
        <?php endif; ?>
    </table>
</body>
</html>

<?php
$conn->close();
?>
