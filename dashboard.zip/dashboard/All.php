<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    // If not logged in, redirect to the login page
    header('Location: index.html');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Table Display</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #eaeaea;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            height: 100vh;
            color: #333;
        }
        h1 {
            margin-top: 20px;
            color: #2c3e50;
        }
        .logout-container {
            margin: 20px 0;
        }
        .logout {
            background-color: #e74c3c;
            border-radius: 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            color: #fff;
            cursor: pointer;
            font-size: 18px;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            transition: background 0.3s, transform 0.3s;
        }
        .logout:hover {
            background: #c0392b;
            transform: translateY(-2px);
        }
        #searchContainer {
            width: 75%;
            text-align: center;
            margin-bottom: 20px;
        }
        #searchInput {
            width: 100%;
            padding: 10px;
            border: 2px solid #2c3e50;
            border-radius: 5px;
            outline: none;
        }
        #searchInput:focus {
            border-color: #3498db;
        }
        #tableContainer {
            width: 75%;
            overflow: auto;
            border: 1px solid #ddd;
            border-radius: 10px;
            background: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 12px;
            transition: background 0.3s;
        }
        th {
            background-color: #3498db;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #d1e6ff;
        }
        @media (max-width: 768px) {
            #searchContainer {
                width: 90%;
            }
            #tableContainer {
                width: 90%;
            }
        }
    </style>
    <script>
        function filterTable() {
            var input, filter, table, tr, td, i, txtValue;
            input = document.getElementById("searchInput");
            filter = input.value.toUpperCase();
            table = document.getElementById("dataTable");
            tr = table.getElementsByTagName("tr");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName("td");
                for (var j = 0; j < td.length; j++) {
                    txtValue = td[j].textContent || td[j].innerText;
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = "";
                        break;
                    } else {
                        tr[i].style.display = "none";
                    }
                }
            }
        }
    </script>
</head>
<body>
    <div>
        <h1>ALL ENTRY DATA</h1>
    </div>
    <div class="logout-container">
        <a href="alllogs.php">
            <button class="logout" role="button"><b>&lt;&lt; Back</b></button>
        </a>
    </div>
    <div id="searchContainer">
        <input type="text" id="searchInput" onkeyup="filterTable()" placeholder="Search for data...">
    </div>

    <div id="tableContainer">
        <table id="dataTable">
            <?php
            // Replace these with your database credentials
            $servername = "localhost";
            $username = "root";
            $password = "Ktanooj@2004";
            $database = "slog";

            // Create connection
            $conn = new mysqli($servername, $username, $password, $database);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // SQL query to retrieve data from your table
            $sql = "SELECT * FROM Rfid";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // Output data of first row with column names
                echo "<tr>";
                $row = $result->fetch_assoc();
                foreach ($row as $key => $value) {
                    echo "<th>" . htmlspecialchars($key) . "</th>";
                }
                echo "</tr>";

                // Output data of each subsequent row
                do {
                    echo "<tr>";
                    foreach ($row as $value) {
                        echo "<td>" . htmlspecialchars($value) . "</td>";
                    }
                    echo "</tr>";
                } while ($row = $result->fetch_assoc());
            } else {
                echo "<tr><td colspan='10'>0 results</td></tr>";
            }
            $conn->close();
            ?>
        </table>
    </div>
</body>
</html>

